import {useState} from "react";
function Multiinput(){
const[Input,SetInput]=useState({});
function functionality(e){
    e.preventDefault();
    console.log("form submitted");
    console.log("current state",Name);
}

return(
    <>
    <form onSubmit={functionality}>
        <label>Enter your name : <input type="text" placeholder="Enter your name : "onChange={(e)=>{setInput(Name=e.target.value)}}/></label>
        <label>Enter your email: <input type="text" placeholder="your mail id : "onChange={(e)=>{SetInput(email=e.target.value)}}/> </label>
        <label>Enter your reg no : <input type="text" placeholder="your phone number : " onChange={(e)=>{SetInput(regno=e.target.value)}}/></label>
        <input type="submit" value="Submit Form/"></input>
   </form>
   </>
)
}
export default Multiinput;