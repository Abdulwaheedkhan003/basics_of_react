import {useState} from "react";
function Listupdate(){
    const[list,setList]=useState([]);
    const[count,setCount]=useState(0);
    function addItem(){
        const itemname='item'+count;
        setList((previousState)=>{return[...previousState,itemname]});
        setCount((previousState)=>{return previousState+1});
    }
    return(
        <>
        <h1>Items are : </h1>
        <button onClick={addItem}>click it </button>
        <li>
            <ul>{
                list.map((el,index)=><li key={index}>{el}</li>)
}</ul>
        </li>   
        </>
    )
}
export default Listupdate;