import {useState} from "react";
function Changeproper(){
const[property,setProperty]=useState({
    color:"red",
    bike:"pulsar",
    id:"123132",
    Name:"kumar"
});
const{color,bike,id,Name}=property;;
function update(){
    setProperty(previousState=>{
        return {...previousState,color:"blue",bike:"activa",id:"14124",Name:"raj"}
    })
}
console.log("current state is called");;
return(
    <>
    <h1>details of a person</h1>
    <p>color:{color}</p>
    <p>bike:{bike}</p>
    <p>id:{id}</p>
    <p>Name:{Name}</p>
    <button onClick={update}>update props   </button>
    </>
);
} 
export default Changeproper;