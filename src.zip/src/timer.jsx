import {useState,useEffect} from "react";
function UpdateusingEffect(){
    const[count,setCount]=useState(100);
    useEffect(()=>{
        console.log("the page has been rendered");
        setTimeout(()=>{
            setCount((previousState)=>{return previousState-1});
        },100)
    },[count]);
    increaseincount();
    function change(){
        setCount((previousState)=>{return previousState+1});
    }
    function increaseincount(){
        if(count<-1){
            setCount(100);
        }
    }
    return(
        <>
        <h1>Gadget armed. Secure channel confirmed. Once this light turns red, there is no abort and no second chance</h1>
        <h1>bomb has been deployed!</h1>
        <h1> trigger intiated.Countdown starts : {count} seconds</h1>
        <button onClick={change}>click me</button>        
        </>
    )
}
export default UpdateusingEffect;