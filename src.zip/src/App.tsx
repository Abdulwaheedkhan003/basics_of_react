import Changeproper from './stateexample1.jsx';
import Listupdate from './stateinarrays.jsx';
import UpdateusingEffect from './timer.jsx';
import Forms from './formexample.jsx';
import Multiinput from './multipleinput.jsx';
function App(){
  return(
    <>
  <Changeproper/>
  <Listupdate/>
  <UpdateusingEffect/>
  <Forms/>
  <Multiinput/>
  </>
  );
}
export default App;
