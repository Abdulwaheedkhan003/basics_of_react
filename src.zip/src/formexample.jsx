import {useState} from "react";
function Forms(){
    const[name,changeNam]=useState("");
    function onSumbit(e){
        e.preventDefault();
        console.log("form is submitted");
        console.log("booooooooooooooommmmmmmmmmm!!!!");
    }
    return(
        <form onSubmit={onSumbit}>
        <input type="text" placeholder="bomb owner's name" onChange={(e)=>(e.target.value)}/>Enter the name janab
        <input type="submit" value="booooommmm"/>
        </form>
    );
}
export default Forms;